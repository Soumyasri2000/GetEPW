const express = require('express');
const router = express.Router();
const EPWFileGenerator = require('../services/EPWFileGenerator');


const epwGenerator = new EPWFileGenerator();

router.post('/generateepw', async (req, res) => {
  const { location, start_date, end_date } = req.body;

  if (!location || !start_date || !end_date) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  try {
    const result = await epwGenerator.generateEPWFile(location, start_date, end_date);
    res.status(200).json(result);
  } catch (err) {
    console.error('EPW generation error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Optional: file download route
router.get('/download_epw/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = `./storage/epw_files/${filename}`;

  res.download(filePath, filename, (err) => {
    if (err) {
      console.error("File download error:", err.message);
      res.status(404).json({ error: "File not found." });
    }
  });
});

module.exports = router;
