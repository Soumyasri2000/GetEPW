const express = require('express');
const router = express.Router();
const EPWDeliverySystem = require('../services/EPWDeliverySystem');

// Load config from environment
const config = {
  emailHost: process.env.EMAIL_HOST,
  emailPort: process.env.EMAIL_PORT,
  emailUser: process.env.EMAIL_USER,
  emailPassword: process.env.EMAIL_PASSWORD,
  shopName: process.env.SHOP_NAME,
  accessToken: process.env.SHOPIFY_ACCESS_TOKEN
};

const deliverySystem = new EPWDeliverySystem(config);

// Webhook handler
router.post('/order_created', async (req, res) => {
  try {
    const order = req.body;
    await deliverySystem.processOrder(order);
    res.status(200).send('Order processed successfully');
  } catch (error) {
    console.error('Failed to process order:', error);
    res.status(500).send('Failed to process order');
  }
});

module.exports = router;
