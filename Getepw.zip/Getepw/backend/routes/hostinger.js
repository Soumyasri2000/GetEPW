const express = require('express');
const SftpClient = require('ssh2-sftp-client');
const router = express.Router();

router.post('/webhooks/Hostinger', async (req, res) => {
  const sftp = new SftpClient();
  try {
    await sftp.connect({
      host: 'your-hostinger-server.com',
      port: 22,
      username: 'your-username',
      password: 'your-password', // or use privateKey
    });

    // Example: download a file from Hostinger to local server
    await sftp.fastGet('/remote/path/to/file.txt', './local/path/to/file.txt');

    await sftp.end();
    res.status(200).send('File transferred successfully');
  } catch (err) {
    res.status(500).send('File transfer failed: ' + err.message);
  }
});

module.exports = router;