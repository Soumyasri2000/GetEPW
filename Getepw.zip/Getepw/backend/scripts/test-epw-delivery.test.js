
require('dotenv').config();
const fs = require('fs');
const path = require('path');

// Mock nodemailer to prevent real SMTP connections
jest.mock('nodemailer', () => {
  const sendMail = jest.fn().mockResolvedValue(true);
  return {
    createTransport: jest.fn(() => ({ sendMail }))
  };
});

const EPWDeliverySystem = require(path.join(__dirname, '../services/EPWDeliverySystem.js'));

describe('EPWDeliverySystem Real SMTP Integration', () => {
  test('sends a real email via SMTP', async () => {
    const config = {
      emailHost: process.env.EMAIL_HOST,
      emailPort: parseInt(process.env.EMAIL_PORT),
      emailUser: process.env.EMAIL_USER,
      emailPassword: process.env.EMAIL_PASSWORD,
      shopName: process.env.SHOP_NAME,
      defaultCredits: 5,
    };
    const epwDelivery = new EPWDeliverySystem(config);

    const epwResult = {
      filename: 'real_test.epw',
      location: 'TestVille',
      year: 2023,
    };

    const fileDir = path.resolve(__dirname, '../../storage/epw_files');
    const filePath = path.join(fileDir, epwResult.filename);
    if (!fs.existsSync(fileDir)) fs.mkdirSync(fileDir, { recursive: true });
    if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, 'EPW test content');

    const testEmail = 'tiger.aster@gmail.com';
    await expect(epwDelivery.sendEmailWithAttachment(testEmail, epwResult)).resolves.not.toThrow();
  }, 30000);
});
