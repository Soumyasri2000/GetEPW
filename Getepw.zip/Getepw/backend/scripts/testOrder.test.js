const axios = require('axios');

// Mock axios to prevent real HTTP requests
jest.mock('axios');

test('should handle order creation with raw data', async () => {
  axios.post.mockResolvedValue({
    status: 200,
    data: { success: true, orderId: '12345' }
  });

  const orderData = {
    email: 'tiger.aster@gmail.com',
    line_items: [
      {
        title: 'Weather Data',
        properties: [
          { name: 'longitude', value: "55.0623"},
          { name: 'latitude', value: "36.1281" },
          { name: 'Location', value: "Kovcheg" },
          { name: 'Year', value: "2023" }
        ]
      }
    ]
  };

  const response = await axios.post('http://localhost:5001/shopify/order_created', orderData);

  expect(response.status).toBe(200);
  expect(response.data.success).toBe(true);
  expect(response.data.orderId).toBe('12345');
});