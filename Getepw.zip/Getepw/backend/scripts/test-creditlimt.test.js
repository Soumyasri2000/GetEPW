const axios = require('axios');

// Mock axios to prevent real HTTP requests
jest.mock('axios');

describe('Credit Limit and Payment Flow', () => {
    test('should process payment with dummy credit card and update credits', async () => {
        // Mock payment processing response
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: { paymentStatus: 'approved', transactionId: 'txn_100' }
        });

        // Mock webhook response
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: { webhookReceived: true }
        });

        // Mock credit management response
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: {
                credits: 5,
                locations: ['Kovcheg', 'Moscow'],
                years: ['2023', '2024']
            }
        });

        // Step 1: Process payment
        const paymentData = {
            card_number: '1',
            expiration_date: '02/30',
            security_code: '123',
            amount: 100,
            currency: 'USD'
        };
        const paymentResponse = await axios.post('http://localhost:5001/payment/process', paymentData);
        expect(paymentResponse.status).toBe(200);
        expect(paymentResponse.data.paymentStatus).toBe('approved');
        expect(paymentResponse.data.transactionId).toBeDefined();

        // Step 2: Trigger webhook
        const webhookResponse = await axios.post('http://localhost:5001/webhook/payment', {
            transactionId: paymentResponse.data.transactionId
        });
        expect(webhookResponse.status).toBe(200);
        expect(webhookResponse.data.webhookReceived).toBe(true);

        // Step 3: Check credit management and selection options
        const creditResponse = await axios.post('http://localhost:5001/user/credits', {
            userEmail: 'tiger.aster@gmail.com'
        });
        expect(creditResponse.status).toBe(200);
        expect(creditResponse.data.credits).toBeGreaterThan(0);
        expect(Array.isArray(creditResponse.data.locations)).toBe(true);
        expect(Array.isArray(creditResponse.data.years)).toBe(true);
    });

    test('should not allow usage if credits are zero', async () => {
        // Mock credit management response with zero credits
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: {
                credits: 0,
                locations: [],
                years: []
            }
        });

        const creditResponse = await axios.post('http://localhost:5001/user/credits', {
            userEmail: 'tiger.aster@gmail.com'
        });

        expect(creditResponse.status).toBe(200);
        expect(creditResponse.data.credits).toBe(0);
        expect(creditResponse.data.locations.length).toBe(0);
        expect(creditResponse.data.years.length).toBe(0);
    });

    test('should decrement credits after using a location/year', async () => {
        // Mock initial credit management response
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: {
                credits: 3,
                locations: ['Kovcheg'],
                years: ['2023']
            }
        });

        // Mock usage response
        axios.post.mockResolvedValueOnce({
            status: 200,
            data: { credits: 2 }
        });

        // Get initial credits
        const creditResponse = await axios.post('http://localhost:5001/user/credits', {
            userEmail: 'tiger.aster@gmail.com'
        });
        expect(creditResponse.data.credits).toBe(3);

        // Use a credit
        const useCreditResponse = await axios.post('http://localhost:5001/user/use_credit', {
            userEmail: 'tiger.aster@gmail.com',
            location: 'Kovcheg',
            year: '2023'
        });
        expect(useCreditResponse.status).toBe(200);
        expect(useCreditResponse.data.credits).toBe(2);
    });
});