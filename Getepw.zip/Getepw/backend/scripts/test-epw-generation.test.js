require('dotenv').config();
const path = require('path');
const fs = require('fs');
const mkdirp = require('mkdirp');
const EPWFileGenerator = require('../services/EPWFileGenerator.js');
const EPWDeliverySystem = require('../services/EPWDeliverySystem.js');

// Mock nodemailer to prevent real emails
jest.mock('nodemailer', () => ({
  createTransport: () => ({
    sendMail: jest.fn().mockResolvedValue(true)
  })
}));
// Create config object from .env
const config = {
  emailHost: process.env.EMAIL_HOST,
  emailPort: Number(process.env.EMAIL_PORT),
  emailUser: process.env.EMAIL_USER,
  emailPassword: process.env.EMAIL_PASSWORD,
  shopName: process.env.SHOP_NAME,
  shopifyAccessToken: process.env.SHOPIFY_ACCESS_TOKEN
};

test('should generate EPW file for London', async () => {
  const generator = new EPWFileGenerator();
  const delivery = new EPWDeliverySystem(config);
  const result = await generator.generateProfessionalEPW('Kovcheg', '2023-01-01', '2023-12-31');
  expect(result).toHaveProperty('filename');
  expect(fs.existsSync(result.filePath)).toBe(true);
  
  //send email with attachment
 await delivery.sendEmailWithAttachment('tiger.aster@gmail.com', {
    filename: result.filename,
    location: 'Mominpet',
    year: '2023'
});
});
// Create directories to ensure they exist
const storageDir = path.resolve(__dirname, '../../storage/epw_files');

console.log('Creating storage directory:');
console.log(`- ${storageDir}`);

mkdirp.sync(storageDir);

  
async function testEPWGeneration() {
  const EPWFileGenerator = require('../services/EPWFileGenerator');
  try {
    console.log('Initializing EPW File Generator...');
    const generator = new EPWFileGenerator();
    
    // Test location and date range
    const location = "Kovcheg" ; // New York coordinates
    const startDate = "2023-01-01";
    const endDate = "2023-12-31";
    
    console.log(`Generating EPW file for location: ${location}`);
    console.log(`Date range: ${startDate} to ${endDate}`);
    
    const result = await generator.generateProfessionalEPW(location, startDate, endDate);
    console.log('Generation completed with result:', result);
    
    // List all files in the directory
    console.log('\nListing files in storage directory:');
    
    console.log(`\nFiles in ${storageDir}:`);
    if (fs.existsSync(storageDir)) {
      const files = fs.readdirSync(storageDir);
      if (files.length > 0) {
        files.forEach(file => console.log(`- ${file}`));
      } else {
        console.log('(No files found)');
      }
    } else {
      console.log('(Directory does not exist)');
    }
    
  } catch (error) {
    console.error('Test failed with error:', error);
  }
}

console.log('Starting EPW generation test...');
testEPWGeneration().then(() => {
  console.log('Test completed.');
}).catch(err => {
  console.error('Test failed:', err);
});
