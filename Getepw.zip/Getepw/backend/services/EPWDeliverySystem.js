const nodemailer = require('nodemailer');
const EPWFileGenerator = require('./EPWFileGenerator');
const path = require('path');
const fs = require('fs');
const mkdirp = require('mkdirp'); // You'll need to install this

class EPWDeliverySystem {
  constructor(config) {
    this.config = config;
    this.epwGenerator = new EPWFileGenerator();

    // TODO: Replace with persistent store in production
    this.userCredits = {}; // { email: credits }
    
    // Ensure storage directory exists
    this.storageDir = path.resolve(__dirname, '../../storage/epw_files');
    mkdirp.sync(this.storageDir);

    this.transporter = nodemailer.createTransport({
      host: config.emailHost,
      port: config.emailPort,
      secure: config.emailPort === 465,
      auth: {
        user: config.emailUser,
        pass: config.emailPassword
      }
    });
  }

  getCredits(email) {
    return this.userCredits[email] || 0;
  }

  decrementCredits(email) {
    if (this.userCredits[email] > 0) {
      this.userCredits[email] -= 1;
      return true;
    }
    return false;
  }

  // Send email when credits are finished for a particular order
  async sendCreditsFinishedEmail(to, orderID) {
    const mailOptions = {
      from: `"${this.config.shopName}" <${this.config.emailUser}>`,
      to,
      subject: `Order ${orderID}: Credits Exhausted`,
      text: `Hi,\n\nWe could not fulfill your order ${orderID} because your credits are finished.\n\nPlease purchase more credits to continue using our service.\n\nBest regards,\n${this.config.shopName}`,
      html: `<p>Hi,</p><p>We could not fulfill your order <b>${orderID}</b> because your credits are finished.</p><p>Please <a href="https://yourshopifydomain.com/collections/all">purchase more credits</a> to continue using our service.</p><p>Best regards,<br>${this.config.shopName}</p>`
    };
    await this.transporter.sendMail(mailOptions);
  }

// ...existing code...

  // Main webhook handler
  async processOrder(order) {
    try {
      const customerEmail = order?.email;
      if (!customerEmail) throw new Error("Missing customer email in order.");

      // Simulate loading or setting initial credits
      if (!this.userCredits[customerEmail]) {
        this.userCredits[customerEmail] = this.config.defaultCredits || 5;
      }

      if (this.userCredits[customerEmail] <= 0) {
        // Send notification email for this order
        let orderID = order.id?.toString() || order.name || "Unknown";
        await this.sendCreditsFinishedEmail(customerEmail, orderID);
        throw new Error(`Customer ${customerEmail} has no remaining credits.`);
      }

      const { coordinates, location, startDate, endDate } = this.extractLocationData(order);

      // Validate coordinates format
      if (!this.validateCoordinates(coordinates)) {
        throw new Error(`Invalid coordinates format: ${coordinates}`);
      }
      // Attempt to get orderID or fallback
      let orderID = order.id?.toString();
      if (!orderID && order.name) {
        console.warn("order.id missing, using order.name as fallback:", order.name);
        orderID = order.name;
      }
      if (!orderID) {
        console.error("Missing both order.id and order.name");
        throw new Error("Cannot proceed without order ID or name");
      }

      const customerID = order.customer?.id ?? null;
      const year = new Date(startDate).getFullYear();

      // Add location if not present in epwResult
      if (!epwResult.location) {
        epwResult.location = location;
      }
      // --- Save order/user details to MySQL ---
      const userId = order?.customer?.id || null;
      const name = (order?.customer?.first_name || '') + ' ' + (order?.customer?.last_name || '');
      const paymentMethod = order?.gateway || (order?.payment_gateway_names ? order.payment_gateway_names[0] : null);
      const email = customerEmail;
      const paymentReferenceId = order?.id ? order.id.toString() : null;

      await pool.execute(
        `INSERT INTO user_purchases 
          (user_id, name, payment_method, email, payment_reference_id, location, start_date, end_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          name,
          paymentMethod,
          email,
          paymentReferenceId,
          location,
          startDate,
          endDate
        ]
      );
      await pool.execute(
        `INSERT INTO transaction
          (order_id,customer_id,location,longitude,latitude,year,fulfilled,credit_used)
          VALUES (?,?,?,?,?,?,?,?)`,
          [
            orderID,
            customerID,
            location, 
            longitude,
            latitude,
            year,
            fulfilled,
            creditused
          ]
      );
      // --- End MySQL insert ---
      await this.sendEmailWithAttachment(customerEmail, epwResult);

      this.decrementCredits(customerEmail);

      // Send credits exhausted email if credits are now zero
      if (this.getCredits(customerEmail) === 0) {
        let orderID = order.id?.toString() || order.name || "Unknown";
        await this.sendCreditsFinishedEmail(customerEmail, orderID);
      }

      console.log(`✅ Delivered EPW to ${customerEmail} (${location}). Remaining credits: ${this.getCredits(customerEmail)}`);
      return { success: true, credits: this.getCredits(customerEmail) };
    } catch (error) {
      console.error("Error processing order:", error);
      throw error;
    }
  }

// ...existing code...

  validateCoordinates(coordinates) {
    // Basic validation - improve as needed
    if (!coordinates) return false;
    
    // Check if it's a string with lat,lon format
    const parts = coordinates.split(',');
    if (parts.length !== 2) return false;
    
    const [lat, lon] = parts.map(p => parseFloat(p.trim()));
    return !isNaN(lat) && !isNaN(lon) && 
           lat >= -90 && lat <= 90 && 
           lon >= -180 && lon <= 180;
  }

  // Extract coordinates, location, and year from order line item properties
  extractLocationData(order) {
    const props = order?.line_items?.[0]?.properties;
    if (!Array.isArray(props)) {
      throw new Error("Missing line item properties.");
    }

    let coordinates = null;
    let location = null;
    let year = null;

    for (const prop of props) {
      const name = prop.name.toLowerCase();
      if (name.includes('coordinate')) coordinates = prop.value;
      if (name.includes('location')) location = prop.value;
      if (name.includes('year')) year = prop.value;
    }

    if (!coordinates || !location || !year) {
      throw new Error("Missing coordinate, location, or year in order properties.");
    }

    return {
      coordinates,
      location,
      startDate: `${year}-01-01`,
      endDate: `${year}-12-31`
    };
  }

  // Email customer with .epw attachment
  async sendEmailWithAttachment(to, epwResult) {

    const filePath = path.resolve(this.storageDir, epwResult.filename);
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${epwResult.filename}`);
    }

    // Construct the public URL for the EPW file
    const publicUrl = `${this.config.publicBaseUrl || 'https://yourdomain.com'}/storage/epw_files/${encodeURIComponent(epwResult.filename)}`;

    const mailOptions = {
      from: `"${this.config.shopName}" <${this.config.emailUser}>`,
      to,
      subject: `Your EPW File for ${epwResult.location}`,
      text: `Hi,\n\nThank you for your order.\n\nYou can download your EPW file for ${epwResult.location} (${epwResult.year}) here: ${publicUrl}\n\nThe file is also attached to this email.\n\nIf you have any questions, feel free to contact us.\n\nBest regards,\n${this.config.shopName}`,
      html: `<p>Hi,</p><p>Thank you for your order.</p><p>You can download your EPW file for <b>${epwResult.location} (${epwResult.year})</b> here:<br><a href="${publicUrl}" download>Download EPW File</a></p><p>The file is also attached to this email.</p><p>If you have any questions, feel free to contact us.</p><p>Best regards,<br>${this.config.shopName}</p>`,
	  attachments: [
        {
          filename: epwResult.filename,
          path: filePath
        }
      ]
    };
    await this.transporter.sendMail(mailOptions);

    // Delete file after successful delivery
    /*
    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(`Failed to delete EPW file: $backend/services/EPWDeliverySystem.js`, err.message);
      } else {
        console.log(`🧹 Deleted EPW file: $backend/services/EPWDeliverySystem.js`);
      }
    }); */
  }
}

module.exports = EPWDeliverySystem;