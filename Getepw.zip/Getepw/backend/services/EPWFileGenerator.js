const path = require('path');
const fs = require('fs');
const axios = require('axios');
const mkdirp = require('mkdirp');
const NodeGeocoder = require('node-geocoder');
const tzlookup = require('tz-lookup');
const {DateTime} = require('luxon');
class ProfessionalEPWGenerator {
  constructor() {
    this.geocoder = NodeGeocoder({ provider: 'openstreetmap' });
    
    // Ensure storage directory exists
    this.storageDir ='/var/www/samoa.getepw.com/files/';
    mkdirp.sync(this.storageDir);

    // EPW missing values per specification
    this.epwMissingValues = {
      dryBulbTemp: 99.9,
      dewPointTemp: 99.9,
      relativeHumidity: 999,
      atmosphericPressure: 999999,
      extHorizRad: 9999,
      extDirNormRad: 9999,
      horizInfraredRad: 9999,
      globalHorizRad: 9999,
      directNormalRad: 9999,
      diffuseHorizRad: 9999,
      globalHorizIllum: 999999,
      directNormIllum: 999999,
      diffuseHorizIllum: 999999,
      zenithLuminance: 9999,
      windDirection: 999,
      windSpeed: 999,
      totalSkyCover: 99,
      opaqueSkyCover: 99,
      visibility: 9999,
      ceilingHeight: 99999,
      precipitableWater: 999,
      aerosolOptDepth: 999,
      snowDepth: 999,
      daysSinceSnow: 99,
      albedo: 999,
      liquidPrecipDepth: 999,
      liquidPrecipQuantity: 99
    };

    // Known ASHRAE climate zones and their characteristics for fallback
    this.climateZoneDefaults = {
      'very_hot_humid': { // Zone 1A
        heating996: 10, heating990: 12, cooling004: 35, cooling010: 33, cooling020: 31
      },
      'hot_humid': { // Zone 2A
        heating996: 2, heating990: 5, cooling004: 34, cooling010: 32, cooling020: 30
      },
      'hot_dry': { // Zone 2B
        heating996: 0, heating990: 3, cooling004: 40, cooling010: 38, cooling020: 36
      },
      'warm_humid': { // Zone 3A
        heating996: -5, heating990: -2, cooling004: 32, cooling010: 30, cooling020: 28
      },
      'warm_dry': { // Zone 3B
        heating996: -8, heating990: -5, cooling004: 36, cooling010: 34, cooling020: 32
      },
      'mixed_humid': { // Zone 4A
        heating996: -12, heating990: -8, cooling004: 30, cooling010: 28, cooling020: 26
      },
      'mixed_dry': { // Zone 4B
        heating996: -15, heating990: -10, cooling004: 32, cooling010: 30, cooling020: 28
      },
      'cool_humid': { // Zone 5A
        heating996: -18, heating990: -14, cooling004: 28, cooling010: 26, cooling020: 24
      },
      'cool_dry': { // Zone 5B
        heating996: -20, heating990: -16, cooling004: 30, cooling010: 28, cooling020: 26
      },
      'cold_humid': { // Zone 6A
        heating996: -23, heating990: -19, cooling004: 26, cooling010: 24, cooling020: 22
      },
      'cold_dry': { // Zone 6B
        heating996: -25, heating990: -21, cooling004: 28, cooling010: 26, cooling020: 24
      },
      'very_cold': { // Zone 7
        heating996: -28, heating990: -24, cooling004: 24, cooling010: 22, cooling020: 20
      },
      'subarctic': { // Zone 8
        heating996: -35, heating990: -30, cooling004: 20, cooling010: 18, cooling020: 16
      }
    };
  }
  async getElevation(lat, lon) {
    try {
      const url = `https://api.open-meteo.com/v1/elevation?latitude=${lat}&longitude=${lon}`;
      const res = await axios.get(url);
      // For Open-Meteo: { elevation: [number] }
      if (Array.isArray(res.data.elevation) && typeof res.data.elevation[0] === 'number') {
        return res.data.elevation[0];
      }
      if (typeof res.data.elevation === 'number') {
        return res.data.elevation;
      }
      return 0;
    } catch (e) {
      console.error('Elevation API error:', e.message);
      return 0;
    }
  }

  // Get timezone from GeoNames (requires free registration and username)
 //adding timezone for API Noinja timezone......
async getTimezone(lat, lon) {
  try {
    const timezoneName = tzlookup(lat, lon); // e.g., "Asia/Kolkata"
    const dt = DateTime.now().setZone(timezoneName);
    const gmtOffset = dt.offset / 60; // offset in hours
    return { gmtOffset, timezoneName };
  } catch (e) {
    console.error('Local timezone lookup error:', e.message);
    return { gmtOffset: 0, timezoneName: 'UTC' };
  }
}

  // Location validation for API
  async validateLocation(location) {
    try {
      if (!location || typeof location !== 'string' || !location.trim()) {
        return { valid: false, message: 'Location string is empty or invalid.' };
      }
      const coordinates = await this.getCoordinates(location);
      console.log('Geocoder result for', location, ':', coordinates);
      if (!coordinates || !coordinates.lat || !coordinates.lon) {
        return { valid: false, message: 'Could not resolve location to coordinates.' };
      }
      if (!coordinates.city && !coordinates.country) {
        return { valid: false, message: 'Location found, but lacks city/country info.' };
      }
      return {
        valid: true,
        message: `Location resolved: ${coordinates.city || ''}, ${coordinates.state || ''}, ${coordinates.country || ''}`.replace(/(, )+/g, ', ').replace(/^, |, $/g, ''),
        details: coordinates
      };
    } catch (err) {
      return { valid: false, message: 'Geocoding error: ' + err.message };
    }
  }


  // Google Maps Geocoding API
  async getCoordinates(locationName) {
  try {
    console.log(`Geocoding location: ${locationName}`);
    const results = await this.geocoder.geocode(locationName);
    if (results && results.length > 0) {
      const result = results[0];
      const lat = result.latitude;
      const lon = result.longitude;
      const [elevation,timezone ] = await Promise.all([
        this.getElevation(lat,lon),
        this.getTimezone(lat,lon),
      ]);
      
      return {
        lat ,
        lon ,
        city: result.city || locationName,
        country: result.country || '',
        state: result.state || '',
        countryCode: result.countryCode || '',
        elevation,
        timezone
      };
    } else {
      throw new Error('Location not found');
    }
  } catch (err) {
    console.error("Geocoding error:", err.message);
    return null;
  }
}

// METHODOLOGY FOR LOCATIONS WITHOUT ASHRAE DATA
  // This is the core solution for your question
  async determineClimateCharacteristics(coordinates, weatherData = null) {
    console.log('=== Determining Climate Characteristics for Location ===');
    
    // Step 1: Try to find existing ASHRAE data
    const ashraeData = await this.lookupASHRAEData(coordinates);
    if (ashraeData) {
      console.log('Found existing ASHRAE data for location');
      return { source: 'ashrae_database', data: ashraeData };
    }

    // Step 2: If no ASHRAE data, analyze historical weather patterns
    if (weatherData) {
      console.log('No ASHRAE data found - analyzing historical weather patterns');
      const computedConditions = this.computeDesignConditionsFromWeather(weatherData);
      return { source: 'computed_from_weather', data: computedConditions };
    }

    // Step 3: Use geographic/climatic zone estimation as fallback
    console.log('Using geographic climate zone estimation as fallback');
    const estimatedConditions = this.estimateClimateFromGeography(coordinates);
    return { source: 'geographic_estimation', data: estimatedConditions };
  }

  async lookupASHRAEData(coordinates) {
    // This would connect to an ASHRAE database or known station data
    // For now, we'll simulate this with a few known locations
    const knownLocations = {
      // Major US cities with known ASHRAE data
      'new_york': { lat: 40.7128, lon: -74.0060, heating996: -8.9, heating990: -5.6, cooling004: 30.0, cooling010: 28.3, cooling020: 26.7 },
      'chicago': { lat: 41.8781, lon: -87.6298, heating996: -17.8, heating990: -13.9, cooling004: 31.1, cooling010: 29.4, cooling020: 27.8 },
      'miami': { lat: 25.7617, lon: -80.1918, heating996: 8.9, heating990: 11.7, cooling004: 32.8, cooling010: 32.2, cooling020: 31.7 },
      'phoenix': { lat: 33.4484, lon: -112.0740, heating996: 1.1, heating990: 3.3, cooling004: 44.4, cooling010: 43.3, cooling020: 42.2 },
      'seattle': { lat: 47.6062, lon: -122.3321, heating996: -3.3, heating990: -1.1, cooling004: 27.8, cooling010: 25.6, cooling020: 23.9 }
    };

    // Check if coordinates are close to any known location (within ~50km)
    for (const [city, data] of Object.entries(knownLocations)) {
      const distance = this.calculateDistance(coordinates.lat, coordinates.lon, data.lat, data.lon);
      if (distance < 50) { // Within 50km
        console.log(`Found nearby ASHRAE data from ${city} (${distance.toFixed(1)}km away)`);
        return {
          heating996: data.heating996,
          heating990: data.heating990,
          cooling004: data.cooling004,
          cooling010: data.cooling010,
          cooling020: data.cooling020,
          source: `ASHRAE_${city.toUpperCase()}`,
          distance: distance
        };
      }
    }

    return null;
  }

  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  computeDesignConditionsFromWeather(weatherData) {
    console.log('Computing ASHRAE design conditions from historical weather data...');
    
    const hourlyData = this.processHourlyData(weatherData);
    
    if (hourlyData.dryBulb.length < 1000) {
      console.warn('Insufficient weather data for reliable design condition calculation');
    }

    // Calculate heating design conditions (99.6% and 99.0% - coldest conditions)
    const sortedTemps = [...hourlyData.dryBulb].sort((a, b) => a - b);
    const heating996 = this.calculatePercentile(sortedTemps, 0.4); // Coldest 0.4%
    const heating990 = this.calculatePercentile(sortedTemps, 1.0); // Coldest 1.0%

    // Calculate cooling design conditions (0.4%, 1.0%, 2.0% - hottest conditions)
    const sortedTempsDesc = [...hourlyData.dryBulb].sort((a, b) => b - a);
    const cooling004 = this.calculatePercentile(sortedTempsDesc, 0.4); // Hottest 0.4%
    const cooling010 = this.calculatePercentile(sortedTempsDesc, 1.0); // Hottest 1.0%
    const cooling020 = this.calculatePercentile(sortedTempsDesc, 2.0); // Hottest 2.0%

    // Calculate coincident conditions
    const heatingConditions = this.calculateHeatingDesignConditions(hourlyData);
    const coolingConditions = this.calculateCoolingDesignConditions(hourlyData);
    const extremeConditions = this.calculateExtremeConditions(hourlyData);

    return {
      heating996: heating996,
      heating990: heating990,
      cooling004: cooling004,
      cooling010: cooling010,
      cooling020: cooling020,
      heatingConditions: heatingConditions,
      coolingConditions: coolingConditions,
      extremeConditions: extremeConditions,
      dataQuality: {
        recordCount: hourlyData.dryBulb.length,
        temperatureRange: { min: Math.min(...hourlyData.dryBulb), max: Math.max(...hourlyData.dryBulb) },
        confidence: hourlyData.dryBulb.length >= 8000 ? 'high' : 'medium'
      }
    };
  }

  estimateClimateFromGeography(coordinates) {
    console.log('Estimating climate characteristics from geographic location...');
    
    const lat = coordinates.lat;
    const lon = coordinates.lon;
    const elevation = coordinates.elevation || 0;

    // Determine climate zone based on latitude, longitude, and elevation
    const climateZone = this.determineClimateZone(lat, lon, elevation);
    const defaults = this.climateZoneDefaults[climateZone];

    // Apply elevation adjustments (temperature typically decreases ~6.5°C per 1000m)
    const elevationAdjustment = (elevation / 1000) * -6.5;

    return {
      heating996: defaults.heating996 + elevationAdjustment,
      heating990: defaults.heating990 + elevationAdjustment,
      cooling004: defaults.cooling004 + elevationAdjustment,
      cooling010: defaults.cooling010 + elevationAdjustment,
      cooling020: defaults.cooling020 + elevationAdjustment,
      climateZone: climateZone,
      elevationAdjustment: elevationAdjustment,
      confidence: 'estimated',
      note: 'Values estimated from geographic location and climate zone'
    };
  }

  determineClimateZone(lat, lon, elevation) {
    // Simplified climate zone determination based on latitude and longitude
    const absLat = Math.abs(lat);
    
    // Very cold/subarctic regions
    if (absLat > 60) return 'subarctic';
    if (absLat > 50) return 'very_cold';
    
    // Cold regions
    if (absLat > 45) {
      return elevation > 1000 ? 'very_cold' : 'cold_humid';
    }
    
    // Cool regions
    if (absLat > 40) {
      // Determine if humid or dry based on longitude (simplified)
      const isDry = this.isDryClimate(lat, lon);
      return isDry ? 'cool_dry' : 'cool_humid';
    }
    
    // Mixed regions
    if (absLat > 35) {
      const isDry = this.isDryClimate(lat, lon);
      return isDry ? 'mixed_dry' : 'mixed_humid';
    }
    
    // Warm regions
    if (absLat > 25) {
      const isDry = this.isDryClimate(lat, lon);
      return isDry ? 'warm_dry' : 'warm_humid';
    }
    
    // Hot regions
    if (absLat > 15) {
      const isDry = this.isDryClimate(lat, lon);
      return isDry ? 'hot_dry' : 'hot_humid';
    }
    
    // Very hot regions (tropical)
    return 'very_hot_humid';
  }

  isDryClimate(lat, lon) {
    // Simplified dry climate determination
    // This is a rough approximation - real climate classification is much more complex
    
    // Major desert regions
    if (lat >= 20 && lat <= 35 && lon >= -120 && lon <= -100) return true; // SW USA
    if (lat >= 15 && lat <= 30 && lon >= -10 && lon <= 30) return true; // Sahara/Middle East
    if (lat >= -35 && lat <= -15 && lon >= 115 && lon <= 145) return true; // Australian outback
    
    // Rain shadow regions (simplified)
    if (elevation > 500 && Math.abs(lat) < 50) {
      // Check if on leeward side of mountains (very simplified)
      return true;
    }
    
    return false;
  }

  // Statistical Analysis Functions (existing code continues...)
  calculatePercentile(sortedData, percentile) {
    const index = (percentile / 100) * (sortedData.length - 1);
    const lower = Math.floor(index);
    const upper = Math.ceil(index);
    const weight = index % 1;
    
    if (upper >= sortedData.length) return sortedData[sortedData.length - 1];
    if (lower < 0) return sortedData[0];
    
    return sortedData[lower] * (1 - weight) + sortedData[upper] * weight;
  }

  processHourlyData(weatherData) {
    const data = {
      dryBulb: [],
      dewPoint: [],
      relativeHumidity: [],
      pressure: [],
      windSpeed: [],
      windDirection: [],
      globalRad: [],
      directRad: [],
      diffuseRad: [],
      months: [],
      hours: []
    };
    
    for (let i = 0; i < weatherData.time.length; i++) {
      const date = new Date(weatherData.time[i]);
      
      // Extract valid data only
      const temp = weatherData.temperature_2m[i];
      const rh = weatherData.relative_humidity_2m[i];
      const dp = weatherData.dew_point_2m[i];
      
      if (!isNaN(temp) && !isNaN(rh) && !isNaN(dp)) {
        data.dryBulb.push(temp);
        data.dewPoint.push(dp);
        data.relativeHumidity.push(rh);
        data.pressure.push(weatherData.surface_pressure ? weatherData.surface_pressure[i] * 100 : 101325);
        data.windSpeed.push((weatherData.wind_speed_10m[i] || 0) / 3.6); // km/h to m/s
        data.windDirection.push(weatherData.wind_direction_10m[i] || 0);
        data.globalRad.push(weatherData.shortwave_radiation[i] || 0);
        data.directRad.push(weatherData.direct_radiation[i] || 0);
        data.diffuseRad.push(weatherData.diffuse_radiation[i] || 0);
        data.months.push(date.getMonth() + 1);
        data.hours.push(date.getHours());
      }
    }
    
    console.log(`Processed ${data.dryBulb.length} valid hourly records`);
    return data;
  }

  calculateHeatingDesignConditions(data) {
    const sortedTemps = [...data.dryBulb].sort((a, b) => a - b);
    
    const heating996 = this.calculatePercentile(sortedTemps, 0.4);
    const heating990 = this.calculatePercentile(sortedTemps, 1.0);
    
    const coincident996Humidity = data.relativeHumidity.filter((_, i) => data.dryBulb[i] <= heating996);
    const coincident996WindSpeed = data.windSpeed.filter((_, i) => data.dryBulb[i] <= heating996);
    
    const monthlyAvgs = {};
    for (let month = 1; month <= 12; month++) {
      const monthTemps = data.dryBulb.filter((_, i) => data.months[i] === month);
      if (monthTemps.length > 0) {
        monthlyAvgs[month] = monthTemps.reduce((a, b) => a + b, 0) / monthTemps.length;
      }
    }
    const coldestMonth = Object.keys(monthlyAvgs).reduce((a, b) => 
      monthlyAvgs[a] < monthlyAvgs[b] ? a : b
    );
    
    return {
      coldestMonth: parseInt(coldestMonth),
      heating996: heating996,
      heating990: heating990,
      meanCoincidentHumidity996: coincident996Humidity.length > 0 ? 
        coincident996Humidity.reduce((a, b) => a + b, 0) / coincident996Humidity.length : 50,
      meanWindSpeed996: coincident996WindSpeed.length > 0 ? 
        coincident996WindSpeed.reduce((a, b) => a + b, 0) / coincident996WindSpeed.length : 2
    };
  }

  calculateCoolingDesignConditions(data) {
    const sortedTemps = [...data.dryBulb].sort((a, b) => b - a);
    
    const cooling004 = this.calculatePercentile(sortedTemps, 0.4);
    const cooling010 = this.calculatePercentile(sortedTemps, 1.0);
    const cooling020 = this.calculatePercentile(sortedTemps, 2.0);
    
    const wetBulbTemps = data.dryBulb.map((temp, i) => 
      this.calculateWetBulbTemperature(temp, data.relativeHumidity[i], data.pressure[i])
    ).filter(wb => wb !== null);
    
    const monthlyAvgs = {};
    for (let month = 1; month <= 12; month++) {
      const monthTemps = data.dryBulb.filter((_, i) => data.months[i] === month);
      if (monthTemps.length > 0) {
        monthlyAvgs[month] = monthTemps.reduce((a, b) => a + b, 0) / monthTemps.length;
      }
    }
    const hottestMonth = Object.keys(monthlyAvgs).reduce((a, b) => 
      monthlyAvgs[a] > monthlyAvgs[b] ? a : b
    );
    
    const hottestMonthTemps = data.dryBulb.filter((_, i) => data.months[i] == hottestMonth);
    const dailyRange = this.calculateDailyRange(hottestMonthTemps);
    
    const coincidentWB004 = wetBulbTemps.filter((_, i) => data.dryBulb[i] >= cooling004);
    const coincidentWB010 = wetBulbTemps.filter((_, i) => data.dryBulb[i] >= cooling010);
    const coincidentWB020 = wetBulbTemps.filter((_, i) => data.dryBulb[i] >= cooling020);
    
    return {
      hottestMonth: parseInt(hottestMonth),
      dailyRange: dailyRange,
      cooling004: cooling004,
      cooling010: cooling010,
      cooling020: cooling020,
      coincidentWB004: coincidentWB004.length > 0 ? 
        coincidentWB004.reduce((a, b) => a + b, 0) / coincidentWB004.length : cooling004 - 10,
      coincidentWB010: coincidentWB010.length > 0 ? 
        coincidentWB010.reduce((a, b) => a + b, 0) / coincidentWB010.length : cooling010 - 10,
      coincidentWB020: coincidentWB020.length > 0 ? 
        coincidentWB020.reduce((a, b) => a + b, 0) / coincidentWB020.length : cooling020 - 10
    };
  }

  calculateExtremeConditions(data) {
    const sortedTemps = [...data.dryBulb].sort((a, b) => a - b);
    const sortedWinds = [...data.windSpeed].sort((a, b) => b - a);
    
    return {
      extremeMinTemp: Math.min(...data.dryBulb),
      extremeMaxTemp: Math.max(...data.dryBulb),
      windSpeed10: this.calculatePercentile(sortedWinds, 1.0),
      windSpeed25: this.calculatePercentile(sortedWinds, 2.5),
      windSpeed50: this.calculatePercentile(sortedWinds, 5.0),
      meanExtremeMin: sortedTemps[0],
      meanExtremeMax: sortedTemps[sortedTemps.length - 1]
    };
  }

  calculateWetBulbTemperature(temp, rh, pressure = 101325) {
    if (isNaN(temp) || isNaN(rh)) return null;
    
    let wb = temp;
    for (let i = 0; i < 20; i++) {
      const es_wb = 611.21 * Math.exp(17.502 * wb / (240.97 + wb));
      const es_db = 611.21 * Math.exp(17.502 * temp / (240.97 + temp));
      const ea = es_db * (rh / 100);
      
      const wb_new = wb - ((es_wb - ea) * (temp - wb)) / (2501000 - 2.326 * wb);
      
      if (Math.abs(wb_new - wb) < 0.01) break;
      wb = wb_new;
    }
    
    return wb;
  }

  calculateDailyRange(monthlyTemps) {
    const max = Math.max(...monthlyTemps);
    const min = Math.min(...monthlyTemps);
    return max - min;
  }

  // ENHANCED DESIGN CONDITIONS ANALYSIS WITH FALLBACK METHODOLOGY
  async analyzeDesignConditions(weatherData, coordinates) {
    console.log('=== Analyzing ASHRAE Design Conditions ===');
    
    // Use the new methodology to determine climate characteristics
    const climateData = await this.determineClimateCharacteristics(coordinates, weatherData);
    
    let heatingConditions, coolingConditions, extremeConditions;
    
    if (climateData.source === 'computed_from_weather') {
      // Use computed values from weather data
      heatingConditions = climateData.data.heatingConditions;
      coolingConditions = climateData.data.coolingConditions;
      extremeConditions = climateData.data.extremeConditions;
      
      console.log(`Design conditions computed from ${climateData.data.dataQuality.recordCount} weather records (${climateData.data.dataQuality.confidence} confidence)`);
    } else {
      // Use estimated or ASHRAE database values with synthetic data
      console.log(`Using ${climateData.source} design conditions`);
      
      heatingConditions = {
        coldestMonth: 1,
        heating996: climateData.data.heating996,
        heating990: climateData.data.heating990,
        meanCoincidentHumidity996: 80,
        meanWindSpeed996: 3.5
      };
      
      coolingConditions = {
        hottestMonth: 7,
        dailyRange: 12,
        cooling004: climateData.data.cooling004,
        cooling010: climateData.data.cooling010,
        cooling020: climateData.data.cooling020,
        coincidentWB004: climateData.data.cooling004 - 8,
        coincidentWB010: climateData.data.cooling010 - 8,
        coincidentWB020: climateData.data.cooling020 - 8
      };
      
      extremeConditions = {
        extremeMinTemp: climateData.data.heating996 - 5,
        extremeMaxTemp: climateData.data.cooling004 + 3,
        windSpeed10: 12,
        windSpeed25: 15,
        windSpeed50: 20,
        meanExtremeMin: climateData.data.heating996,
        meanExtremeMax: climateData.data.cooling004
      };
    }
    
    return this.formatDesignConditions(heatingConditions, coolingConditions, extremeConditions, climateData);
  }

  formatDesignConditions(heating, cooling, extreme, climateData) {
    // Add metadata about data source
    const sourceNote = climateData.source === 'computed_from_weather' ? 
      'Computed from Historical Weather Data' :
      climateData.source === 'ashrae_database' ? 
        'ASHRAE Database' : 
        'Estimated from Geographic Location';
    
    const heatingStr = `Heating,1,${heating.heating996.toFixed(1)},${heating.heating990.toFixed(1)},-4.7,2.6,9.6,-2.5,3.1,9,7.4,7.9,6.7,8.9,1.3,0`;
    const coolingStr = `Cooling,${cooling.hottestMonth},${cooling.dailyRange.toFixed(1)},${cooling.cooling004.toFixed(1)},${cooling.coincidentWB004.toFixed(1)},${cooling.cooling010.toFixed(1)},${cooling.coincidentWB010.toFixed(1)},${cooling.cooling020.toFixed(1)},${cooling.coincidentWB020.toFixed(1)},27.2,32.4,26.9,31.8,26.6,31.3,2.6,200,26,21.5,29.3,25.6,21.1,29,25.3,20.6,28.8,86.9,32.6,85.1,32.1,83.7,31.6,766`;
    const extremeStr = `Extremes,${extreme.windSpeed50.toFixed(1)},${extreme.windSpeed25.toFixed(1)},${extreme.windSpeed10.toFixed(1)},29.9,0.3,${extreme.extremeMaxTemp.toFixed(1)},1.4,1.1,-0.7,${extreme.extremeMaxTemp.toFixed(1)},-1.5,${extreme.extremeMaxTemp.toFixed(1)},-2.3,${extreme.extremeMaxTemp.toFixed(1)},-3.3,${extreme.extremeMaxTemp.toFixed(1)}`;
    
    return {
      formatted: `1,Climate Design Data - ${sourceNote},,${heatingStr},${coolingStr},${extremeStr}`,
      metadata: {
        source: climateData.source,
        confidence: climateData.data.confidence || 'unknown',
        note: sourceNote
      }
    };
  }

  // Continue with rest of existing methods...
  async fetchWeatherData(lat, lon, startDate, endDate) {
    const url = "https://archive-api.open-meteo.com/v1/archive";

    const params = {
      latitude: lat,
      longitude: lon,
      start_date: startDate,
      end_date: endDate,
      hourly: [
        'temperature_2m',
        'relative_humidity_2m',
        'dew_point_2m',
        'surface_pressure',
        'shortwave_radiation',
        'direct_radiation',
        'diffuse_radiation',
        'wind_speed_10m',
        'wind_direction_10m',
        'cloud_cover',
        'precipitation'
      ],
      timezone: 'auto'
    };

    try {
      console.log('Fetching weather data from Open-Meteo API...');
      const res = await axios.get(url, { params });
      console.log(`Successfully fetched ${res.data.hourly.time.length} hourly records`);
      return res.data.hourly;
    } catch (err) {
      console.error("Weather data fetch error:", err.message);
      throw new Error(`Failed to fetch weather data: ${err.message}`);
    }
  }

  // Main EPW generation function with enhanced methodology
  async generateProfessionalEPW(location, startDate, endDate) {
    console.log('=== Professional EPW Generation Started ===');
    
    // Get location coordinates
    let coordinates;
    if (typeof location === 'object' && location.lat && location.lon) {
      // If elevation/timezone missing, fetch them
      if (coordinates.elevation === undefined || coordinates.timezone === undefined) {
        const [elevation, timezone] = await Promise.all([
          this.getElevation(location.lat, location.lon),
          this.getTimezone(location.lat, location.lon)
        ]);
        coordinates = { ...location, elevation, timezone };
      } else {
        coordinates = location;
      }
    } else if (typeof location === 'string') {
      coordinates = await this.getCoordinates(location);
      if (!coordinates) throw new Error(`Invalid or unresolved location: ${location}`);
    } else {
      throw new Error('Invalid location format');
    }

    // Fetch complete weather dataset
    const weatherData = await this.fetchWeatherData(
      coordinates.lat, 
      coordinates.lon, 
      startDate, 
      endDate
    );
    
    // Generate professional EPW content with statistical analysis
    const epwContent = await this.generateProfessionalEPWContent(weatherData, coordinates, location);
    
    // Save file
    const locationStr = typeof location === 'string' ? location : coordinates.city || `${coordinates.lat}_${coordinates.lon}`;
    const filename = `${locationStr.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_professional_${startDate}_${endDate}.epw`;
    const filePath = path.join(this.storageDir, filename);
    
    fs.writeFileSync(filePath, epwContent);
    
    console.log('=== Professional EPW Generation Completed ===');
    
    return {
      filename,
      filePath,
      location,
      coordinates,
      recordCount: weatherData.time.length,
      dataQuality: this.assessDataQuality(weatherData)
    };
  }

  async generateProfessionalEPWContent(weatherData, coordinates, locationName) {
  const startDate = new Date(weatherData.time[0]);
  const year = startDate.getFullYear();
  const jan1 = new Date(year, 0, 1);
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const jan1DayOfWeek = daysOfWeek[jan1.getDay()];

  // --- Robust location string logic ---
  let city = coordinates.city && coordinates.city.trim() ? coordinates.city.trim() : '';
  let state = coordinates.state && coordinates.state.trim() ? coordinates.state.trim() : '';
  let country = coordinates.country && coordinates.country.trim() ? coordinates.country.trim() : '';
  let locParts = [];
  if (city) locParts.push(city);
  if (state) locParts.push(state);
  if (country) locParts.push(country);
  if (locParts.length === 0) {
    locParts.push(`${coordinates.lat.toFixed(4)},${coordinates.lon.toFixed(4)}`);
  }
  const timezoneOffset = coordinates.timezone && typeof coordinates.timezone === 'object'
      ? coordinates.timezone.gmtOffset
      : coordinates.timezone !== undefined
        ? coordinates.timezone
        : 0;
    const elevation = coordinates.elevation !== undefined ? coordinates.elevation : 0;

    // Build your LOCATION line
    const locationStr = [coordinates.city, coordinates.state, coordinates.country]
      .filter(Boolean)
      .join(',');

  console.log('Generating professional EPW headers with statistical analysis...');
  
  // Generate ASHRAE design conditions using enhanced methodology
  const designConditions = await this.analyzeDesignConditions(weatherData, coordinates);
  
  // Generate typical/extreme periods
  const typicalExtremePeriods = this.analyzeTypicalExtremePeriods(weatherData);
  
  // Generate ground temperatures
  const groundTemperatures = this.calculateGroundTemperatures(weatherData);
  
  // Create professional header with methodology notes
  const header = [
    // Line 1: LOCATION with professional metadata
    //`LOCATION,${locationStr},WMO=${Math.floor(coordinates.lat * 100)}${Math.floor(coordinates.lon * 100)},${coordinates.lat.toFixed(4)},${coordinates.lon.toFixed(4)},${timezone},${elevation}`,
    `LOCATION,${locationStr},WMO=${Math.floor(coordinates.lat * 100)}${Math.floor(coordinates.lon * 100)},${coordinates.lat.toFixed(4)},${coordinates.lon.toFixed(4)},${timezoneOffset},${elevation}`,
    // Line 2: DESIGN CONDITIONS with methodology source
    `DESIGN CONDITIONS,${designConditions.formatted}`,
    
    // Line 3: TYPICAL/EXTREME PERIODS
    `TYPICAL/EXTREME PERIODS,6,${typicalExtremePeriods}`,
    
    // Line 4: GROUND TEMPERATURES
    `GROUND TEMPERATURES,${groundTemperatures}`,
    
    // Line 5: HOLIDAYS/DAYLIGHT SAVINGS
    `HOLIDAYS/DAYLIGHT SAVINGS,No,0,0,0`,
    
    // Line 6: COMMENTS 1 with methodology info
    `COMMENTS 1,Professional EPW File - Design Conditions: ${designConditions.metadata.note}`,
    
    // Line 7: COMMENTS 2 with data source and confidence
    `COMMENTS 2,Source: Open-Meteo Historical API | Confidence: ${designConditions.metadata.confidence || 'computed'} | Records: ${weatherData.time.length}`,
    
    // Line 8: DATA PERIODS
    `DATA PERIODS,1,1,Data,${jan1DayOfWeek},1/1,12/31`
  ].join('\n') + '\n';
  
  console.log('Generating hourly weather data records...');
  
  // Generate hourly data records
  const dataRows = this.generateProfessionalDataRows(weatherData);
  
  return header + dataRows;
}

  // Typical/Extreme Periods Analysis
  analyzeTypicalExtremePeriods(weatherData) {
    console.log('Analyzing typical and extreme periods...');
    
    const weeklyAverages = this.calculateWeeklyAverages(weatherData);
    
    const extremeHotWeek = this.findExtremeWeek(weeklyAverages, 'hot');
    const typicalSummerWeek = this.findTypicalWeek(weeklyAverages, 'summer');
    const extremeColdWeek = this.findExtremeWeek(weeklyAverages, 'cold');
    const typicalWinterWeek = this.findTypicalWeek(weeklyAverages, 'winter');
    const typicalAutumnWeek = this.findTypicalWeek(weeklyAverages, 'autumn');
    const typicalSpringWeek = this.findTypicalWeek(weeklyAverages, 'spring');
    
    return [
      `Summer - Week Nearest Max Temperature For Period,Extreme,${extremeHotWeek.start},${extremeHotWeek.end}`,
      `Summer - Week Nearest Average Temperature For Period,Typical,${typicalSummerWeek.start},${typicalSummerWeek.end}`,
      `Winter - Week Nearest Min Temperature For Period,Extreme,${extremeColdWeek.start},${extremeColdWeek.end}`,
      `Winter - Week Nearest Average Temperature For Period,Typical,${typicalWinterWeek.start},${typicalWinterWeek.end}`,
      `Autumn - Week Nearest Average Temperature For Period,Typical,${typicalAutumnWeek.start},${typicalAutumnWeek.end}`,
      `Spring - Week Nearest Average Temperature For Period,Typical,${typicalSpringWeek.start},${typicalSpringWeek.end}`
    ].join(',');
  }

  calculateWeeklyAverages(weatherData) {
    const weeklyData = [];
    const startDate = new Date(weatherData.time[0]);
    
    for (let week = 0; week < 52; week++) {
      const weekStart = new Date(startDate);
      weekStart.setDate(startDate.getDate() + (week * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      
      const weekTemps = [];
      for (let i = 0; i < weatherData.time.length; i++) {
        const currentDate = new Date(weatherData.time[i]);
        if (currentDate >= weekStart && currentDate <= weekEnd) {
          const temp = weatherData.temperature_2m[i];
          if (!isNaN(temp)) weekTemps.push(temp);
        }
      }
      
      if (weekTemps.length > 0) {
        weeklyData.push({
          week: week + 1,
          startDate: weekStart,
          endDate: weekEnd,
          avgTemp: weekTemps.reduce((a, b) => a + b, 0) / weekTemps.length,
          maxTemp: Math.max(...weekTemps),
          minTemp: Math.min(...weekTemps)
        });
      }
    }
    
    return weeklyData;
  }

  findExtremeWeek(weeklyAverages, type) {
    let targetWeek;
    if (type === 'hot') {
      targetWeek = weeklyAverages.reduce((prev, current) => 
        prev.maxTemp > current.maxTemp ? prev : current
      );
    } else {
      targetWeek = weeklyAverages.reduce((prev, current) => 
        prev.minTemp < current.minTemp ? prev : current
      );
    }
    
    return {
      start: this.formatDate(targetWeek.startDate),
      end: this.formatDate(targetWeek.endDate)
    };
  }

  findTypicalWeek(weeklyAverages, season) {
    const seasonalMonths = {
      summer: [6, 7, 8],
      winter: [12, 1, 2],
      autumn: [9, 10, 11],
      spring: [3, 4, 5]
    };
    
    const seasonWeeks = weeklyAverages.filter(week => {
      const month = week.startDate.getMonth() + 1;
      return seasonalMonths[season].includes(month);
    });
    
    if (seasonWeeks.length === 0) return { start: '1/1', end: '1/7' };
    
    const avgSeasonTemp = seasonWeeks.reduce((sum, week) => sum + week.avgTemp, 0) / seasonWeeks.length;
    
    const typicalWeek = seasonWeeks.reduce((prev, current) => 
      Math.abs(prev.avgTemp - avgSeasonTemp) < Math.abs(current.avgTemp - avgSeasonTemp) ? prev : current
    );
    
    return {
      start: this.formatDate(typicalWeek.startDate),
      end: this.formatDate(typicalWeek.endDate)
    };
  }

  formatDate(date) {
    return `${date.getMonth() + 1}/${date.getDate()}`;
  }

  // Ground Temperature Analysis
  calculateGroundTemperatures(weatherData) {
    console.log('Calculating ground temperatures...');
    
    const monthlyAirTemps = this.calculateMonthlyAverages(weatherData);
    const depths = [0.5, 2.0, 4.0];
    const groundTemps = [];
    
    depths.forEach(depth => {
      const monthlyGroundTemps = this.calculateGroundTempAtDepth(monthlyAirTemps, depth);
      groundTemps.push({
        depth: depth,
        conductivity: 1.5, // W/m-K (typical soil)
        density: 1800, // kg/m³ (typical soil)
        specificHeat: 1200, // J/kg-K (typical soil)
        monthlyTemps: monthlyGroundTemps
      });
    });
    
    return this.formatGroundTemperatures(groundTemps);
  }

  calculateMonthlyAverages(weatherData) {
    const monthlyTemps = {};
    
    for (let month = 1; month <= 12; month++) {
      monthlyTemps[month] = [];
    }
    
    for (let i = 0; i < weatherData.time.length; i++) {
      const date = new Date(weatherData.time[i]);
      const month = date.getMonth() + 1;
      const temp = weatherData.temperature_2m[i];
      
      if (!isNaN(temp)) {
        monthlyTemps[month].push(temp);
      }
    }
    
    // Calculate averages
    for (let month = 1; month <= 12; month++) {
      if (monthlyTemps[month].length > 0) {
        monthlyTemps[month] = monthlyTemps[month].reduce((a, b) => a + b, 0) / monthlyTemps[month].length;
      } else {
        monthlyTemps[month] = 15; // Default temperature
      }
    }
    
    return monthlyTemps;
  }

  calculateGroundTempAtDepth(monthlyAirTemps, depth) {
    const annualMeanTemp = Object.values(monthlyAirTemps).reduce((a, b) => a + b, 0) / 12;
    const amplitude = (Math.max(...Object.values(monthlyAirTemps)) - Math.min(...Object.values(monthlyAirTemps))) / 2;
    
    // Depth damping factor
    const dampingFactor = Math.exp(-depth / 2);
    const phaseLag = depth * 30; // days
    
    const groundTemps = {};
    
    for (let month = 1; month <= 12; month++) {
      const dayOfYear = (month - 1) * 30 + 15; // Mid-month
      const phaseAdjustedDay = dayOfYear - phaseLag;
      const seasonalVariation = amplitude * dampingFactor * Math.sin(2 * Math.PI * phaseAdjustedDay / 365);
      
      groundTemps[month] = annualMeanTemp + seasonalVariation;
    }
    
    return groundTemps;
  }

  formatGroundTemperatures(groundTemps) {
    const lines = [];
    
    groundTemps.forEach(depthData => {
      const monthlyValues = [];
      for (let month = 1; month <= 12; month++) {
        monthlyValues.push(depthData.monthlyTemps[month].toFixed(2));
      }
      
      lines.push(`${depthData.depth},,,,${depthData.conductivity.toFixed(2)},${depthData.density},${depthData.specificHeat},${monthlyValues.join(',')}`);
    });
    
    return `${groundTemps.length},${lines.join(',')}`;
  }

  generateProfessionalDataRows(weatherData) {
    let dataRows = '';
    let validRecords = 0;
    let missingDataSummary = {
      temperature: 0,
      humidity: 0,
      dewPoint: 0,
      pressure: 0,
      solar: 0,
      wind: 0
    };
    // Get Open-Meteo arrays
    const openMeteo = this.openMeteoData || {};
    const hourly = openMeteo.hourly || {};
    const minutely = openMeteo['minutely_15'] || {};
    
    for (let i = 0; i < weatherData.time.length; i++) {
      const date = new Date(weatherData.time[i]);
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      const hour = date.getHours();
      const minute = date.getMinutes();
      const epwHour = hour === 0 ? 24 : hour;
      const dataFlags = '?9?9?9?9E0?9?9?9?9?9?9?9?9?9?9?9?9?9?9?9*9*9?9?9?9';
      const ghi = hourly.shortwave_radiation ? hourly.shortwave_radiation[i] : this.epwMissingValues.globalHorizRad;
      const dni = hourly.direct_normal_irradiance ? hourly.direct_normal_irradiance[i] : this.epwMissingValues.directNormalRad;
      const dhi = hourly.diffuse_radiation ? hourly.diffuse_radiation[i] : this.epwMissingValues.diffuseHorizRad;
      const vis = minutely.visibility ? minutely.visibility[i] : this.epwMissingValues.visibility;
      const snow = minutely.snowfall_height ? minutely.snowfall_height[i] : this.epwMissingValues.snowDepth;
      const pw = minutely.vapour_pressure_deficit ? minutely.vapour_pressure_deficit[i] : this.epwMissingValues.precipitableWater;
      
      // Core meteorological data with professional validation
      const temp = this.validateProfessionalField(weatherData.temperature_2m[i], 'temperature', -70, 70);
      const dewPoint = this.validateProfessionalField(weatherData.dew_point_2m[i], 'dewPoint', -70, 70);
      const rh = this.validateProfessionalField(weatherData.relative_humidity_2m[i], 'humidity', 0, 110);
      
      const rawPressure = weatherData.surface_pressure ? weatherData.surface_pressure[i] : null;
      let pressure = 101325;
      if (rawPressure && !isNaN(rawPressure)) {
        pressure = rawPressure * 100;
        pressure = this.validateProfessionalField(pressure, 'pressure', 31000, 120000);
      } else {
        pressure = this.epwMissingValues.atmosphericPressure;
        missingDataSummary.pressure++;
      }
      
      const globalRad = this.validateProfessionalField(weatherData.shortwave_radiation[i], 'solar', 0, 1500);
      const directRad = this.validateProfessionalField(weatherData.direct_radiation[i], 'solar', 0, 1200);
      const diffuseRad = this.validateProfessionalField(weatherData.diffuse_radiation[i], 'solar', 0, 800);
      
      const rawWindSpeed = weatherData.wind_speed_10m[i];
      let windSpeed = 0;
      if (rawWindSpeed !== null && rawWindSpeed !== undefined && !isNaN(rawWindSpeed)) {
        windSpeed = this.validateProfessionalField(rawWindSpeed / 3.6, 'wind', 0, 40);
      } else {
        windSpeed = this.epwMissingValues.windSpeed;
        missingDataSummary.wind++;
      }
      
      const rawWindDir = weatherData.wind_direction_10m[i];
      let windDir = 0;
      if (rawWindDir !== null && rawWindDir !== undefined && !isNaN(rawWindDir)) {
        windDir = this.validateProfessionalField(rawWindDir, 'wind', 0, 360);
      } else {
        windDir = this.epwMissingValues.windDirection;
      }
      // --- PATCH END ---

      const rawCloudCover = weatherData.cloud_cover ? weatherData.cloud_cover[i] : null;
      let totalSkyCover = this.epwMissingValues.totalSkyCover;
      if (rawCloudCover !== null && !isNaN(rawCloudCover)) {
        totalSkyCover = Math.round(rawCloudCover / 10);
        totalSkyCover = this.validateProfessionalField(totalSkyCover, 'sky', 0, 10);
      }
      
      const precip = this.validateProfessionalField(weatherData.precipitation[i], 'precip', 0, 200);
      
      // Data quality tracking
      if (temp !== this.epwMissingValues.dryBulbTemp) validRecords++;
      else missingDataSummary.temperature++;
      
      if (rh === this.epwMissingValues.relativeHumidity) missingDataSummary.humidity++;
      if (dewPoint === this.epwMissingValues.dewPointTemp) missingDataSummary.dewPoint++;
      if (globalRad === this.epwMissingValues.globalHorizRad) missingDataSummary.solar++;
      
      // Professional EPW record formatting (all 34 fields)
      const epwRecord = [
        year, month, day, epwHour, minute, dataFlags,
        this.formatEPWValue(temp, 1),
        this.formatEPWValue(dewPoint, 1), 
        this.formatEPWValue(rh, 0),
        this.formatEPWValue(pressure, 0),
        this.epwMissingValues.extHorizRad,
        this.epwMissingValues.extDirNormRad,
        this.calculateHorizontalInfraredRadiation(temp, dewPoint, totalSkyCover),
        this.formatEPWValue(globalRad, 0),
        this.formatEPWValue(directRad, 0),
        this.formatEPWValue(diffuseRad, 0),
        this.epwMissingValues.globalHorizIllum,
        this.epwMissingValues.directNormIllum,
        this.epwMissingValues.diffuseHorizIllum,
        this.epwMissingValues.zenithLuminance,
        this.formatEPWValue(windDir, 0),
        this.formatEPWValue(windSpeed, 1),
        this.formatEPWValue(totalSkyCover, 0),
        this.epwMissingValues.opaqueSkyCover,
        this.epwMissingValues.visibility,
        this.epwMissingValues.ceilingHeight,
        0, // Present weather observation
        this.generateWeatherCodes(precip, totalSkyCover),
        this.epwMissingValues.precipitableWater,
        this.formatEPWValue(0.999, 3),
        this.epwMissingValues.snowDepth,
        this.epwMissingValues.daysSinceSnow,
        this.epwMissingValues.albedo,
        this.formatEPWValue(precip, 1),
        this.formatEPWValue(precip > 0 ? 1 : this.epwMissingValues.liquidPrecipQuantity, 0)
      ].join(',') + '\n';
      
      dataRows += epwRecord;
    }
    
    console.log('=== Data Quality Summary ===');
    console.log(`Total records processed: ${weatherData.time.length}`);
    console.log(`Valid temperature records: ${validRecords} (${(validRecords/weatherData.time.length*100).toFixed(1)}%)`);
    console.log(`Missing data summary:`, missingDataSummary);
    
    return dataRows;
  }

  validateProfessionalField(value, fieldType, min = null, max = null) {
    if (value === null || value === undefined || isNaN(value) || !isFinite(value)) {
      return this.getMissingValueByType(fieldType);
    }
    
    if (min !== null && value < min) return this.getMissingValueByType(fieldType);
    if (max !== null && value > max) return this.getMissingValueByType(fieldType);
    
    return value;
  }

  getMissingValueByType(fieldType) {
    const typeMap = {
      temperature: this.epwMissingValues.dryBulbTemp,
      dewPoint: this.epwMissingValues.dewPointTemp,
      humidity: this.epwMissingValues.relativeHumidity,
      pressure: this.epwMissingValues.atmosphericPressure,
      solar: this.epwMissingValues.globalHorizRad,
      wind: this.epwMissingValues.windSpeed,
      sky: this.epwMissingValues.totalSkyCover,
      precip: this.epwMissingValues.liquidPrecipDepth
    };
    
    return typeMap[fieldType] || 999;
  }

  formatEPWValue(value, decimals) {
    if (value >= 999 || isNaN(value)) {
      return Math.round(value);
    }
    return typeof value === 'number' ? value.toFixed(decimals) : value;
  }

  calculateHorizontalInfraredRadiation(temp, dewPoint, skyCover) {
    if (temp === this.epwMissingValues.dryBulbTemp || 
        dewPoint === this.epwMissingValues.dewPointTemp) {
      return this.epwMissingValues.horizInfraredRad;
    }
    
    try {
      const tempK = temp + 273.15;
      const dewPointK = dewPoint + 273.15;
      const sigma = 5.6697e-8;
      
      const skyEmissivity = (0.787 + 0.764 * Math.log(dewPointK / 273.0)) * 
                           (1 + 0.0224 * skyCover - 0.0035 * Math.pow(skyCover, 2) + 
                            0.00028 * Math.pow(skyCover, 3));
      
      const horizontalIR = skyEmissivity * sigma * Math.pow(tempK, 4);
      
      return Math.round(horizontalIR);
    } catch (error) {
      return this.epwMissingValues.horizInfraredRad;
    }
  }

  generateWeatherCodes(precipitation, cloudCover) {
    let codes = '999999999';
    
    if (precipitation > 0) {
      if (precipitation < 0.25) {
        codes = '929999999';
      } else if (precipitation < 0.76) {
        codes = '919999999';
      } else {
        codes = '909999999';
      }
    }
    
    return codes;
  }

  assessDataQuality(weatherData) {
    const totalRecords = weatherData.time.length;
    let validTemp = 0;
    let validHumidity = 0;
    let validPressure = 0;
    let validSolar = 0;
    let validWind = 0;
    
    for (let i = 0; i < totalRecords; i++) {
      if (!isNaN(weatherData.temperature_2m[i])) validTemp++;
      if (!isNaN(weatherData.relative_humidity_2m[i])) validHumidity++;
      if (weatherData.surface_pressure && !isNaN(weatherData.surface_pressure[i])) validPressure++;
      if (!isNaN(weatherData.shortwave_radiation[i])) validSolar++;
      if (!isNaN(weatherData.wind_speed_10m[i])) validWind++;
    }
    
    return {
      totalRecords,
      completeness: {
        temperature: (validTemp / totalRecords * 100).toFixed(1) + '%',
        humidity: (validHumidity / totalRecords * 100).toFixed(1) + '%', 
        pressure: (validPressure / totalRecords * 100).toFixed(1) + '%',
        solar: (validSolar / totalRecords * 100).toFixed(1) + '%',
        wind: (validWind / totalRecords * 100).toFixed(1) + '%'
      },
      overallQuality: ((validTemp + validHumidity + validSolar) / (totalRecords * 3) * 100).toFixed(1) + '%'
    };
  }

  // Utility method for batch processing multiple locations
  async generateBatchEPW(locations, startDate, endDate) {
    console.log(`Starting batch EPW generation for ${locations.length} locations`);
    const results = [];
    
    for (let i = 0; i < locations.length; i++) {
      try {
        console.log(`Processing location ${i + 1}/${locations.length}: ${locations[i]}`);
        const result = await this.generateProfessionalEPW(locations[i], startDate, endDate);
        results.push({ location: locations[i], success: true, result });
        
        if (i < locations.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      } catch (error) {
        console.error(`Failed to process ${locations[i]}:`, error.message);
        results.push({ location: locations[i], success: false, error: error.message });
      }
    }
    
    return results;
  }

  // Method to validate EPW file format
  validateEPWFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n');
      
      const requiredHeaders = ['LOCATION', 'DESIGN CONDITIONS', 'TYPICAL/EXTREME PERIODS', 
                              'GROUND TEMPERATURES', 'HOLIDAYS/DAYLIGHT SAVINGS', 
                              'COMMENTS 1', 'COMMENTS 2', 'DATA PERIODS'];
      
      const validation = {
        isValid: true,
        errors: [],
        warnings: [],
        headerCount: 0,
        dataRecordCount: 0
      };
      
      // Validate headers
      for (let i = 0; i < Math.min(8, lines.length); i++) {
        const expectedHeader = requiredHeaders[i];
        if (lines[i].startsWith(expectedHeader)) {
          validation.headerCount++;
        } else {
          validation.errors.push(`Line ${i + 1}: Expected header '${expectedHeader}'`);
          validation.isValid = false;
        }
      }
      
      // Count data records
      for (let i = 8; i < lines.length; i++) {
        if (lines[i].trim()) {
          const fields = lines[i].split(',');
          if (fields.length >= 34) {
            validation.dataRecordCount++;
          } else if (fields.length > 6) {
            validation.warnings.push(`Line ${i + 1}: Record has ${fields.length} fields (expected 34)`);
          }
        }
      }
      
      if (validation.dataRecordCount < 8000) {
        validation.warnings.push(`Only ${validation.dataRecordCount} data records found (expected ~8760 for full year)`);
      }
      
      return validation;
    } catch (error) {
      return {
        isValid: false,
        errors: [`Failed to validate file: ${error.message}`],
        warnings: [],
        headerCount: 0,
        dataRecordCount: 0
      };
    }
  }
}

module.exports = ProfessionalEPWGenerator;
