require('dotenv').config();
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const { auth } = require('express-oauth2-jwt-bearer');
const authConfig = require('./src/auth_config.json');
const ProfessionalEPWGenerator = require('./backend/services/EPWFileGenerator');
const nodemailer = require('nodemailer');
const db = require('./db'); // MySQL connection

const port = process.env.API_PORT || 3002;
const appPort = process.env.SERVER_PORT || 3000;
const appOrigin = authConfig.appOrigin || `http://localhost:${appPort}`;

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT),
  secure: Number(process.env.EMAIL_PORT) === 465,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

async function sendCreditsFinishedEmail(to, orderID) {
  console.log(`Sending credits exhausted warning email to ${to} for order ${orderID}`);
  const mailOptions = {
    from: `"${process.env.SHOP_NAME || 'GetEPW'}" <${process.env.EMAIL_USER}>`,
    to,
    subject: `Notice: Your credits are now zero on GetEPW`,
    text: `Hi,

You have just used your last available credit to generate an EPW file${orderID ? ' (Order: ' + orderID + ')' : ''}.

You do not have enough credits to generate another EPW file next time.

Please purchase more credits to continue using our service.

Best regards,
${process.env.SHOP_NAME || 'GetEPW'}`,
    html: `<p>Hi,</p>
<p>You have just used your <b>last available credit</b> to generate an EPW file${orderID ? ' (Order: <b>' + orderID + '</b>)' : ''}.</p>
<p><b>You do not have enough credits to generate another EPW file next time.</b></p>
<p>Please <a href="${process.env.PUBLIC_DOMAIN || 'https://samoa.getepw.com'}/plans">purchase more credits</a> to continue using our service.</p>
<p>Best regards,<br>${process.env.SHOP_NAME || 'GetEPW'}</p>`
  };
  await transporter.sendMail(mailOptions);
}

if (
  !authConfig.domain ||
  !authConfig.audience ||
  authConfig.audience === "{yourApiIdentifier}"
) {
  console.log(
    "Exiting: Please make sure that auth_config.json is in place and populated with valid domain and audience values"
  );
  process.exit(1);
}

const app = express();

app.use(morgan('dev'));
app.use(helmet());
const allowedOrigins = [
  'https://samoa.getepw.com',
  'https://getepw.com',
  'https://www.getepw.com',
  'http://localhost:3000'
];

app.use(cors({
  origin: function(origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) {
      return callback(null, true);
    } else {
      return callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true
}));
app.use(bodyParser.json());

app.use('/files', express.static('/var/www/samoa.getepw.com/files/'));

const checkJwt = auth({
  audience: authConfig.audience,
  issuerBaseURL: `https://${authConfig.domain}/`,
  algorithms: ["RS256"],
});

// --- MySQL-based API Endpoints ---

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Auth validation
app.get("/api/external", checkJwt, (req, res) => {
  res.send({ msg: "Your access token was successfully validated!" });
});

// GET api/user/{email}
app.get('/api/user/:email', async (req, res) => {
  try {
    const email = req.params.email;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }
    // Check if user exists
    const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length > 0) {
      // Fetch user's files
      const [files] = await db.execute('SELECT * FROM epw_downloads WHERE user_email = ?', [email]);
      return res.json({ ...rows[0], files });
    } else {
      // Create new user with 2 credits
      await db.execute('INSERT INTO users (email,username,credits, createdAt) VALUES (?,?,?,NOW())', [email,email, 2]);
      return res.status(201).json({ email, credits: 2, files: [] });
    }
  } catch (error) {
    console.error('Error processing request:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/topup
app.post('/api/topup',checkJwt,async (req, res) => {
  try {
    const { email, amount } = req.body;
    if (!email || !amount) {
      return res.status(400).json({ error: 'Email and amount are required' });
    }
    if (typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ error: 'Amount must be a positive number' });
    }
    const requestUser = req.auth.payload.sub || req.auth.payload.email;
    const isAdmin = req.auth.payload.permissions && 
                    req.auth.payload.permissions.includes('admin:all');
    if (!isAdmin && requestUser !== email) {
      return res.status(403).json({ error: 'Unauthorized to add credits to this account' });
    }
    // Update credits
    const [rows] = await db.execute('SELECT credits FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    const newCredits = (rows[0].credits || 0) + amount;
    await db.execute('UPDATE users SET credits = ?, lastTopup = NOW() WHERE email = ?', [newCredits, email]);
    return res.json({ email, previousCredits: rows[0].credits || 0, addedCredits: amount, currentCredits: newCredits });
  } catch (error) {
    console.error('Error processing topup:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/generateepw
app.post('/api/generateepw', async (req, res) => {
  let connection;
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    const { email, location, start_date, end_date } = req.body;
    if (!email || !location || !start_date || !end_date) {
      await connection.rollback();
      return res.status(400).json({ error: 'Email, location, start_date, and end_date are required' });
    }
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(start_date) || !dateRegex.test(end_date)) {
      await connection.rollback();
      return res.status(400).json({ error: 'Dates must be in YYYY-MM-DD format' });
    }
    const startDate = new Date(start_date);
    const endDate = new Date(end_date);
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      await connection.rollback();
      return res.status(400).json({ error: 'Invalid date values' });
    }
    if (endDate < startDate) {
      await connection.rollback();
      return res.status(400).json({ error: 'End date must be after start date' });
    }
    const startYear = startDate.getFullYear();
    const endYear = endDate.getFullYear();
    const yearCount = endYear - startYear + 1;
    const requiredCredits = yearCount;

    // Check user and credits
    const [rows] = await connection.execute('SELECT credits FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'User not found' });
    }
    if (rows[0].credits < requiredCredits) {
      await connection.rollback();
      await sendCreditsFinishedEmail(email, null);
      return res.status(403).json({ error: `Insufficient credits. This request requires ${requiredCredits} credits, but you have ${rows[0].credits}.` });
    }

    // Generate EPW file
    const generator = new ProfessionalEPWGenerator();
    const epwData = await generator.generateProfessionalEPW(location, start_date, end_date);
    if (!epwData || !epwData.filename) {
      await connection.rollback();
      throw new Error('EPW file generation failed');
    }

    // Deduct credits and store file info
    const newCredits = rows[0].credits - requiredCredits;
    await connection.execute('UPDATE users SET credits = ?, lastUsed = NOW() WHERE email = ?', [newCredits, email]);
    await connection.execute(
      'INSERT INTO epw_downloads (user_email, epw_filename, downloaded_at, location, coordinates, start_date, end_date) VALUES (?, ?, NOW(), ?, ?, ?, ?)',
      [email, epwData.filename, epwData.location, JSON.stringify(epwData.coordinates), start_date, end_date]
    );

    await connection.commit();

    if (newCredits === 0) {
      await sendCreditsFinishedEmail(email, epwData.filename);
    }

    const publicDomain = 'https://samoa.getepw.com';
    const fullDownloadUrl = `${publicDomain}/files/${epwData.filename}`;

    return res.json({
      message: 'EPW file generated successfully',
      epwData: {
        ...epwData,
        downloadUrl: fullDownloadUrl
      },
      creditsUsed: requiredCredits,
      creditsRemaining: newCredits,
      fileKey: epwData.filename
    });
  } catch (error) {
    if (connection) await connection.rollback();
    console.error('Error generating EPW file:', error);
    return res.status(500).json({ error: 'Failed to generate EPW file', details: error.message });
  } finally {
    if (connection) connection.release();
  }
});

// POST /api/verify-location
app.post('/api/verify-location', async (req, res) => {
  try {
    const { location } = req.body;
    if (!location) {
      return res.status(400).json({ error: 'Location is required' });
    }
    const generator = new ProfessionalEPWGenerator();
    const result = await generator.validateLocation(location);
    if (result && result.valid) {
      return res.json({ valid: true, message: result.message || 'Location is valid', details: result.details });
    } else {
      return res.status(400).json({ valid: false, message: result && result.message ? result.message : 'Invalid location', details: result && result.details });
    }
  } catch (error) {
    console.error('Error validating location:', error);
    return res.status(500).json({ error: 'Failed to validate location', details: error.message });
  }
});

// Admin-only endpoint - Get all users
app.get('/api/admin/users',  async (req, res) => {
  try {
    //const isAdmin = req.auth.payload.permissions && req.auth.payload.permissions.includes('admin:all');
    //if (!isAdmin) {
      //return res.status(403).json({ error: 'Unauthorized: Admin access required' });
    //}
    const [users] = await db.execute('SELECT * FROM users LIMIT 100');
    return res.json({ users });
  } catch (error) {
    console.error('Error fetching users:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 3002;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
module.exports = app;